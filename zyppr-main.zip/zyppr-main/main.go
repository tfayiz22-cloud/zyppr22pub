package main

import (
    "crypto/rand"
    "crypto/rsa"
    "fmt"
    "log"
    "net"
    "net/http"
    "net/http/httputil"
    "net/url" // ADD THIS IMPORT
    "os"
        "html/template" // ADD THIS
    "strings"
    "sync"
    "time"
    "golang.org/x/crypto/ssh"
    "zyppr-tunnel/ssh_server"
)

// Add these global variables for session management
var (
    sessionPorts = make(map[string]string) // sessionID -> port
    sessionMu    sync.RWMutex
)

// Add these functions to main.go
func registerSession(sessionID, port string) {
    sessionMu.Lock()
    sessionPorts[sessionID] = port
    sessionMu.Unlock()
    log.Printf("Registered session routing: %s -> :%s", sessionID, port)
}

func unregisterSession(sessionID string) {
    sessionMu.Lock()
    delete(sessionPorts, sessionID)
    sessionMu.Unlock()
    log.Printf("Unregistered session routing: %s", sessionID)
}

func GetSessionPort(sessionID string) (string, bool) {
    sessionMu.RLock()
    defer sessionMu.RUnlock()
    port, exists := sessionPorts[sessionID]
    return port, exists
}

func isServiceRunning(port string) bool {
    conn, err := net.DialTimeout("tcp", "localhost:"+port, 2*time.Second)
    if err != nil {
        return false
    }
    conn.Close()
    return true
}

// ADD THIS: Landing page HTML template
const landingPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zyppr Tunnel - {{.SessionID}}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        .logo { 
            font-size: 2.5em; 
            font-weight: bold; 
            margin-bottom: 10px;
            background: linear-gradient(45deg, #fff, #e0e0e0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .status { 
            background: rgba(255, 255, 255, 0.2); 
            padding: 15px; 
            border-radius: 10px; 
            margin: 20px 0;
            font-family: 'Courier New', monospace;
        }
        .stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin: 20px 0;
        }
        .stat-item {
            background: rgba(255, 255, 255, 0.15);
            padding: 15px;
            border-radius: 10px;
        }
        .url {
            background: rgba(0, 0, 0, 0.3);
            padding: 12px;
            border-radius: 8px;
            margin: 15px 0;
            word-break: break-all;
            font-family: 'Courier New', monospace;
        }
        .btn {
            background: rgba(255, 255, 255, 0.2);
            border: 2px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
            margin: 5px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }
        .btn-primary {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
            font-weight: bold;
        }
        .btn-primary:hover {
            background: rgba(255, 255, 255, 0.4);
        }
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .service-status {
            margin: 15px 0;
            padding: 10px;
            border-radius: 8px;
        }
        .service-up {
            background: rgba(76, 175, 80, 0.3);
            border: 1px solid rgba(76, 175, 80, 0.5);
        }
        .service-down {
            background: rgba(244, 67, 54, 0.3);
            border: 1px solid rgba(244, 67, 54, 0.5);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">Z⁴</div>
        <h1>Tunnel Active</h1>
        <p>Your secure tunnel is running</p>
        
        <div class="status">
            <div class="loading"></div>
            <span id="status-text">Checking service status...</span>
        </div>
        
        <div id="service-status" class="service-status service-down" style="display: none;">
            ⚠️ Service not responding yet
        </div>
        
        <div class="stats">
            <div class="stat-item">
                <div>Session</div>
                <strong>{{.SessionID}}</strong>
            </div>
            <div class="stat-item">
                <div>Port</div>
                <strong>{{.Port}}</strong>
            </div>
        </div>
        
        <div class="url">
            {{.URL}}
        </div>
        
        <div style="margin: 25px 0;">
            <a href="?bypass=true" class="btn btn-primary" id="visit-btn" style="display: none;">
    		🚀 Visit Your Site
	    </a>
	    <button class="btn" onclick="checkService()">
                🔄 Check Status
            </button>
        </div>
        
        <div style="font-size: 0.9em; opacity: 0.8; margin-top: 20px;">
            <p>If your local service is running, click "Visit Your Site" to access it</p>
            <p>Powered by Zyppr Tunnels</p>
        </div>
    </div>

    <script>
    let serviceChecked = false;

    window.addEventListener('load', function() {
        checkService();
    });

    function checkService() {
        const statusText = document.getElementById('status-text');
        const serviceStatus = document.getElementById('service-status');
        const visitBtn = document.getElementById('visit-btn');

        statusText.innerHTML = '<div class="loading"></div> Checking service...';
        serviceStatus.style.display = 'none';
        visitBtn.style.display = 'none';

        // Add X-Service-Check header to identify this as a check
        fetch(window.location.href, {
            headers: {
                'X-Service-Check': 'true'
            }
        })
        .then(response => {
            if (response.status === 200) {
                // Check if response is the landing page or actual service
                return response.text().then(text => {
                    if (text.includes('Zyppr Tunnel') && text.includes('landing page')) {
                        // Still getting landing page
                        throw new Error('Still landing page');
                    }
                    return response;
                });
            } else {
                throw new Error('Service not ready');
            }
        })
        .then(response => {
            // Service is ready!
            statusText.innerHTML = '✅ Service is ready!';
            serviceStatus.className = 'service-status service-up';
            serviceStatus.innerHTML = '✅ Your local service is responding';
            serviceStatus.style.display = 'block';

            // Update button to include bypass parameter
            visitBtn.style.display = 'inline-block';
            visitBtn.href = window.location.href + '?bypass=true';

            serviceChecked = true;
            
            // Optional: Auto-redirect after 2 seconds
            //setTimeout(() => {
            //    window.location.href = window.location.href + '?bypass=true';
            //}, 2000);
        })
        .catch(error => {
            statusText.innerHTML = '⏳ Waiting for service...';
            serviceStatus.className = 'service-status service-down';
            serviceStatus.innerHTML = '⚠️ Make sure your local service is running on port {{.Port}}';
            serviceStatus.style.display = 'block';

            // Auto-retry after 3 seconds
            if (!serviceChecked) {
                setTimeout(checkService, 3000);
            }
        });
    }

    // Auto-refresh status every 10 seconds
    setInterval(checkService, 10000);
</script>

</body>
</html>`

// Landing page data structure
type LandingPageData struct {
    SessionID string
    URL       string
    Port      string
    //BypassURL string
}

// ServeLandingPage serves the landing page when no actual service is running
func ServeLandingPage(w http.ResponseWriter, r *http.Request, sessionID string, port string) {
    // Check if there's an actual service running on the port
    // If not, serve the landing page
    
    tmpl, err := template.New("landing").Parse(landingPageHTML)
    if err != nil {
        http.Error(w, "Error generating page", http.StatusInternalServerError)
        return
    }
    
    data := LandingPageData{
        SessionID: sessionID,
        URL:       r.Host,
        Port:      port,
    }
    
    w.Header().Set("Content-Type", "text/html")
    tmpl.Execute(w, data)
}

func startHTTPProxy(baseDomain string) {

	// Simple: Always proxy, never show landing page
    
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
    host := r.Host
    log.Printf("DEBUG: Request received - Host: %s, Path: %s", host, r.URL.Path)

    cleanHost := strings.Split(host, ":")[0]
    //sessionID := strings.TrimSuffix(cleanHost, ".free.zyppr.online")
	sessionID := strings.TrimSuffix(cleanHost, "."+baseDomain)

    log.Printf("DEBUG: Clean host: %s, Session ID: %s", cleanHost, sessionID)

    port, exists := GetSessionPort(sessionID)
    if !exists || port == "" {
        log.Printf("ERROR: Session not found for routing: %s", sessionID)
        http.NotFound(w, r)
        return
    }

    log.Printf("DEBUG: Session found - %s -> port %s", sessionID, port)

    // ====== BYPASS LOGIC ======
    // Check if bypass parameter is present
    bypassParam := r.URL.Query().Get("bypass")
    isServiceCheck := r.Header.Get("X-Service-Check") == "true"

    log.Printf("DEBUG: bypass param: %s, isServiceCheck: %v", bypassParam, isServiceCheck)

    // If it's a service check request from JavaScript, always proxy
    if isServiceCheck {
        log.Printf("DEBUG: Service check request - proxying directly")
        proxyToService(w, r, sessionID, port)
        return
    }

    // If bypass=true, always proxy (skip landing page)
    if bypassParam == "true" {
        log.Printf("DEBUG: Bypass enabled - proxying to service")
        proxyToService(w, r, sessionID, port)
        return
    }

    // If it's root path with no bypass, show landing page
    if r.URL.Path == "/" || r.URL.Path == "" {
        log.Printf("DEBUG: Showing landing page for session %s", sessionID)
        ServeLandingPage(w, r, sessionID, port)
        return
    }

    // For all other paths, proxy to service
    log.Printf("DEBUG: Non-root path - proxying to service")
    proxyToService(w, r, sessionID, port)
})
    log.Println("Starting HTTP router on :80")
    go func() {
        if err := http.ListenAndServe(":80", nil); err != nil { // ← Change from :8080 to :80
            log.Fatalf("Failed to start HTTP router: %v", err)
        }
    }()
}

func proxyToService(w http.ResponseWriter, r *http.Request, sessionID, port string) {
    log.Printf("Proxying request for session %s to localhost:%s%s", sessionID, port, r.URL.Path)
    
    targetURL, err := url.Parse(fmt.Sprintf("http://localhost:%s", port))
    if err != nil {
        log.Printf("Error parsing target URL: %v", err)
        http.Error(w, "Internal server error", http.StatusInternalServerError)
        return
    }
    
    proxy := httputil.NewSingleHostReverseProxy(targetURL)
    
    // Update request for proxy
    r.URL.Host = fmt.Sprintf("localhost:%s", port)
    r.URL.Scheme = "http"
    r.Header.Set("X-Forwarded-Host", r.Host)
    r.Header.Set("X-Forwarded-Proto", "http")
    
    proxy.ServeHTTP(w, r)
}

func main() {
    // Parse command line arguments
    if len(os.Args) < 2 {
        log.Fatalf("Usage: %s <online|tunl>", os.Args[0])
    }

    mode := os.Args[1]
    var baseDomain string

    switch mode {
    case "online":
        baseDomain = "free.zyppr.online"
        log.Println("Running in ONLINE mode")
    case "tunl":
        baseDomain = "tunl.zyppr.xyz"
        log.Println("Running in TUNL mode")
    default:
        log.Fatalf("Invalid mode: %s. Use 'online' or 'tunl'", mode)
    }

   startHTTPProxy(baseDomain string)
   // Set up the bridge between packages
   ssh_server.SetSessionCallbacks(registerSession, unregisterSession)
    // Generate host key
    privateKey, err := rsa.GenerateKey(rand.Reader, 2048)
    if err != nil {
        log.Fatalf("failed to generate private key: %v", err)
    }

    signer, err := ssh.NewSignerFromKey(privateKey)
    if err != nil {
        log.Fatalf("failed to create signer: %v", err)
    }

    // SSH server configuration
    config := &ssh.ServerConfig{
        PasswordCallback: func(c ssh.ConnMetadata, pass []byte) (*ssh.Permissions, error) {
            username := c.User()
            password := string(pass)

            if username == "test" && password == "secret" {
                log.Printf("login success for user=%s from %s", username, c.RemoteAddr())
                return nil, nil
            }

            if username == "qr" {
                log.Printf("QR login success for user=%s from %s", username, c.RemoteAddr())
                return nil, nil
            }

            log.Printf("login failed for user=%s from %s", username, c.RemoteAddr())
            return nil, fmt.Errorf("password rejected for %q", username)
        },
        NoClientAuth: false,
    }
    config.AddHostKey(signer)

    // Listen on TCP port 2222
    listener, err := net.Listen("tcp", ":2222")
    if err != nil {
        log.Fatalf("failed to listen on 0.0.0.0:2222: %v", err)
    }

    log.Printf("SSH server listening on 0.0.0.0:2222")
    log.Printf("Using domain: %s", baseDomain)

    for {
        tcpConn, err := listener.Accept()
        if err != nil {
            log.Printf("failed to accept incoming connection: %v", err)
            continue
        }
        // Pass baseDomain as parameter
        go ssh_server.HandleSSHConn(tcpConn, config, baseDomain)
    }
}
