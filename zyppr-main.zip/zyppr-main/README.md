SSH Tunnel Server

A Go-based SSH server that provides remote port forwarding with web interface, QR code access, and real-time monitoring.
Project Structure
text

rtunnel/
├── main.go                 # Entry point - server initialization and main loop
├── go.mod                 # Go module dependencies
├── go.sum                 # Dependency checksums
└── ssh_server/            # Core SSH server package
    ├── session.go         # Session management and traffic tracking
    ├── forwarding.go      # Port forwarding logic and UFW configuration
    ├── channels.go        # SSH channel handling and connection management
    └── utils.go           # Utilities, QR generation, and message formatting

Architecture
Core Components

    Main Server (main.go)

        SSH server configuration

        Host key generation

        Connection acceptance loop

    Session Management (session.go)

        Track active user sessions

        Monitor traffic statistics

        Request logging

        Connection counting

    Port Forwarding (forwarding.go)

        Remote port forwarding (SSH -R)

        Automatic UFW port configuration

        HTTP request detection and logging

        Forwarding URL generation

    Channel Handling (channels.go)

        SSH session channels

        Direct TCP/IP channels

        Real-time monitoring display

        Interactive shell sessions

    Utilities (utils.go)

        QR code generation

        Welcome messages

        Session ID generation

        Byte formatting

Key Features
Authentication

    Password-based auth (test/secret)

    QR code user access (qr/any-password)

    Session-based access control

Port Forwarding

    Remote forwarding (-R flag support)

    Automatic port assignment (port 0)

    Multiple simultaneous forwards

    UFW auto-configuration

Web Access

    Custom subdomain URLs (session-id.tunl.zyppr.xyz)

    QR code generation for mobile access

    HTTP request logging and monitoring

Monitoring

    Real-time traffic statistics

    Active connection tracking

    Request/response counting

    Session expiry timers

Usage Examples
Basic Access
bash

ssh -p 2222 test@your-server-ip

QR Code Access with Port Forwarding
bash

# Random port assignment
ssh -p 2222 -R 0:localhost:8000 qr@your-server-ip

Access URLs

    Primary: http://session-id.tunl.zyppr.xyz

    Port-specific: http://session-id.tunl.zyppr.xyz:port

Development
Building and Running
bash

go run main.go <tunl | online>

Code Organization

    Package ssh_server: All core SSH server functionality

    Package main: Application entry point and server bootstrap

    Separation of Concerns: Each file handles specific functionality

Key Data Structures
SessionInfo

Tracks user sessions with:

    Traffic statistics (bytes sent/received)

    Connection counts

    Active port forwards

    Request logs

    Session timing

ForwardInfo

Manages port forwarding:

    Requested vs actual ports

    Target destinations

    Generated URLs

Adding New Features

    New SSH Channel Types: Add to handleChannels() in channels.go

    New Global Requests: Add to handleGlobalRequests() in forwarding.go

    Session Extensions: Modify sessionInfo struct in session.go

    UI Enhancements: Update monitoring in handleSessionChannel()

Dependencies

    golang.org/x/crypto/ssh - SSH protocol implementation

    github.com/skip2/go-qrcode - QR code generation

Security Notes

    Automatic UFW port opening for forwarded ports

    Session-based isolation

    Password authentication for test accounts

    QR user with per-session access

Monitoring Interface

The SSH session provides real-time monitoring:

    Traffic statistics (received/sent)

    Request/response counts

    Active/total connections

    Session time remaining

    Recent HTTP requests

License
