package ssh_server

import (
    "fmt"
    "sync"
    "time"
)

type requestLog struct {
    Method     string
    Path       string
    StatusCode int
    Timestamp  time.Time
}

type forwardInfo struct {
    RequestedPort uint32
    ActualPort    uint32
    Target        string
    HTTPURL       string  // Change from URL to HTTPURL
    HTTPSURL      string  // Add HTTPSURL
}

type sessionInfo struct {
        ID         string
        Username   string
        RemoteAddr string
        Forwards   map[uint32]*forwardInfo
        BaseURL    string
        // Traffic statistics
        BytesReceived uint64
        BytesSent     uint64
        Requests      uint32
        Responses     uint32
        ActiveConns   uint32
        TotalConns    uint32
        // Timer
        StartTime    time.Time
        ExpiryTime   time.Time
        RequestLogs  []*requestLog
        mu           sync.RWMutex
}

func (s *sessionInfo) updateTraffic(received, sent uint64, isRequest bool) {
        s.mu.Lock()
        defer s.mu.Unlock()

        s.BytesReceived += received
        s.BytesSent += sent
        if isRequest {
                s.Requests++
        } else {
                s.Responses++
        }
}

func (s *sessionInfo) updateConnectionCount(active, total int) {
        s.mu.Lock()
        defer s.mu.Unlock()

        s.ActiveConns = uint32(active)
        if total > 0 {
                s.TotalConns = uint32(total)
        }
}

func (s *sessionInfo) getTrafficStats() (received, sent uint64, requests, responses uint32, active, total uint32) {
        s.mu.RLock()
        defer s.mu.RUnlock()

        return s.BytesReceived, s.BytesSent, s.Requests, s.Responses, s.ActiveConns, s.TotalConns
}

func (s *sessionInfo) getTimeRemaining() string {
        s.mu.RLock()
        remaining := time.Until(s.ExpiryTime)
        s.mu.RUnlock()

        if remaining <= 0 {
                return "EXPIRED"
        }

        minutes := int(remaining.Minutes())
        seconds := int(remaining.Seconds()) % 60
        return fmt.Sprintf("%02d:%02d", minutes, seconds)
}

func (s *sessionInfo) logRequest(method, path string, statusCode int) {
    s.mu.Lock()
    defer s.mu.Unlock()

    log := &requestLog{
        Method:     method,
        Path:       path,
        StatusCode: statusCode,
        Timestamp:  time.Now(),
    }

    if len(s.RequestLogs) >= 10 {
        s.RequestLogs = s.RequestLogs[1:]
    }
    s.RequestLogs = append(s.RequestLogs, log)

    fmt.Printf("  %s %s %d - Session: %s", method, path, statusCode, s.ID)
}
