package ssh_server

import (
    "fmt"
    "io"
    "log"
    "net"
    "sync"
    "time"
    "golang.org/x/crypto/ssh"
    "crypto/rand"
    "strings"
    "bufio"
//    "zyppr-tunnel"
)

func HandleSSHConn(tcpConn net.Conn, config *ssh.ServerConfig,baseDomain string) {
        defer tcpConn.Close()

        serverConn, chans, reqs, err := ssh.NewServerConn(tcpConn, config)
        if err != nil {
                log.Printf("failed to handshake: %v", err)
                return
        }
        defer serverConn.Close()

        log.Printf("new SSH connection from %s (%s)", serverConn.RemoteAddr(), serverConn.ClientVersion())

        sessionID := generateSessionID()
        baseURL := fmt.Sprintf("http://%s.%s", sessionID, baseDomain)
        startTime := time.Now()
        expiryTime := startTime.Add(40 * time.Minute)

        session := &sessionInfo{
                ID:         sessionID,
                Username:   serverConn.User(),
                RemoteAddr: serverConn.RemoteAddr().String(),
                Forwards:   make(map[uint32]*forwardInfo),
                BaseURL:    baseURL,
                StartTime:  startTime,
                ExpiryTime: expiryTime,
        }

        forwards := make(map[forwardKey]*net.TCPListener)

        var wg sync.WaitGroup
        wg.Add(2)

        go func() {
                defer wg.Done()
                handleGlobalRequests(serverConn, reqs, forwards, session)
        }()

        go func() {
                defer wg.Done()
                handleChannels(chans, session)

		 }()

         wg.Wait()

         // Cleanup
         for _, l := range forwards {
                 l.Close()
         }

         log.Printf("session ended: %s (user: %s)", session.ID, session.Username)
 }


 func handleChannels(chans <-chan ssh.NewChannel, session *sessionInfo) {
         for newChannel := range chans {
                 switch newChannel.ChannelType() {
                 case "session":
                         channel, requests, err := newChannel.Accept()
                         if err != nil {
                                 log.Printf("could not accept session channel: %v", err)
                                 continue
                         }
                         go handleSessionChannel(channel, requests, session)

                 case "direct-tcpip":
                         // Handle direct TCP/IP connections (for local forwarding)
                         var req directTCPIPPayload
                         err := ssh.Unmarshal(newChannel.ExtraData(), &req)
                         if err != nil {
                                 log.Printf("could not parse direct-tcpip payload: %v", err)
                                 newChannel.Reject(ssh.ConnectionFailed, "invalid payload")
                                 continue
                         }

                         channel, requests, err := newChannel.Accept()
                         if err != nil {
                                 log.Printf("could not accept direct-tcpip channel: %v", err)
                                 continue
                         }
                         go handleDirectTCPIP(channel, requests, &req, session)

                 default:
                         log.Printf("rejecting channel type: %s", newChannel.ChannelType())
                         newChannel.Reject(ssh.UnknownChannelType, "unsupported channel type")
                 }
         }
 }

 func handleSessionChannel(channel ssh.Channel, requests <-chan *ssh.Request, session *sessionInfo) {
    defer channel.Close()

    // Send initial welcome message
     
    channel.Write([]byte("Scan the QR code below:\r\n\r\n"))
    
    // Show QR code for QR users
     if session.Username == "qr" && len(session.Forwards) > 0 {
	for _, forward := range session.Forwards {
            qrCode := generateQRCode(forward.HTTPURL[:strings.LastIndex(forward.HTTPURL, ":")])
            channel.Write([]byte(qrCode))
            urlMessage := fmt.Sprintf("URL: %s\r\n", forward.HTTPSURL[:strings.LastIndex(forward.HTTPSURL, ":")])
        channel.Write([]byte(urlMessage))
	    break // Only show first QR code
        }
    }

    // Show simple exit instruction
    channel.Write([]byte("\033[60;1H Press 'q' or Ctrl+C to exit...\r\n"))
    // Use channels for coordination
    done := make(chan bool, 1)

    // Start monitoring in a goroutine

    // In handleSessionChannel, update the monitoring goroutine:
go func() {
    updateTicker := time.NewTicker(2 * time.Second)
    expireTicker := time.NewTicker(30 * time.Second)
    defer updateTicker.Stop()
    defer expireTicker.Stop()

    // Track previous request count to avoid flickering

    for {
        select {
        case <-updateTicker.C:
            // Get current stats
            received, sent, reqCount, resCount, active, total := session.getTrafficStats()
            timeRemaining := session.getTimeRemaining()

	                 status := fmt.Sprintf("\033[27;5H📊 %s | Recv: %s | Sent: %s | Req: %d | Res: %d | Active: %d | Total: %d | Time: %s",
                 time.Now().Format("15:04:05"),
                 formatBytes(received),
                 formatBytes(sent),
                 reqCount,
                 resCount,
                 active,
                 total,
                 timeRemaining)

             channel.Write([]byte(status))

             // Show recent HTTP requests at the bottom (line 5 onwards)
             session.mu.RLock()
             if len(session.RequestLogs) > 0 {
                 // Clear previous request area (lines 5-15)
                 // Show last 10 requests starting from line 5
                 start := len(session.RequestLogs) - 10
                 if start < 0 {
                     start = 0
                 }

                 lineNum := 5
                 requestStartRow := 5
                 for i := start; i < len(session.RequestLogs); i++ {
                     if lineNum > requestStartRow+10 { // Don't go beyond allocated area
                             break
                         }
                     log := session.RequestLogs[i]
                     // Format like: > GET 200 /api/users
                     requestLine := fmt.Sprintf("\033[%d;100H%s\033[38;2;37;211;102m%s %d %s\033[0m",

                         lineNum,
                         strings.Repeat("",40),
                         log.Method,
                         log.StatusCode,
                         log.Path)
                     channel.Write([]byte(requestLine))
                     lineNum++
                     if lineNum > 15 { break }
		                    }
           }
           session.mu.RUnlock()

           // Move cursor back to a safe position (after status line)
           channel.Write([]byte("\033[40;1H"))

       case <-expireTicker.C:
           if timeRemaining := session.getTimeRemaining(); timeRemaining == "EXPIRED" {
               channel.Write([]byte("\n\n❌ Tunnel expired! Connection closed.\n"))
               done <- true
               return
           }

       case <-done:
           return
       }
   }
       }()


   go func() {
       for req := range requests {
           switch req.Type {
           case "shell":
               req.Reply(true, nil)
           case "pty-req":
               req.Reply(true, nil)
           default:
               if req.WantReply {
                   req.Reply(false, nil)
               }
           }
       }
   }()

   // Wait for any input (ENTER key) from client
go func() {
    reader := bufio.NewReader(channel)
    for {
        char, err := reader.ReadByte()
        if err != nil {
            if err != io.EOF {
                log.Printf("Read error: %v", err)
            }
            done <- true
            return
        }

        // Check for 'q' or Ctrl+C (ASCII 3)
        if char == 'q' || char == 'Q' || char == 3 {
            channel.Write([]byte("\n\nClosing tunnel... Goodbye!\n"))
            done <- true
            return
        }


    }
}()

// Wait for exit signal
<-done
log.Printf("Client session ended: %s", session.ID)


}

 func generateSessionID() string {
         const charset = "abcdefghijklmnopqrstuvwxyz0123456789"
         const length = 12

         bytes := make([]byte, length)
         if _, err := rand.Read(bytes); err != nil {
                 for i := range bytes {
                         bytes[i] = charset[i%len(charset)]
                 }
         } else {
                 for i, b := range bytes {
                         bytes[i] = charset[b%byte(len(charset))]
                 }
         }
         return string(bytes)
 }

  func handleDirectTCPIP(channel ssh.Channel, reqs <-chan *ssh.Request, payload *directTCPIPPayload, session *sessionInfo) {
         defer channel.Close()

         // Handle channel requests
         go func() {
                 for req := range reqs {
                         if req.WantReply {
                                 req.Reply(true, nil)
                         }
                 }
         }()

         // Connect to the target
         targetAddr := fmt.Sprintf("%s:%d", payload.Host, payload.Port)
         conn, err := net.Dial("tcp", targetAddr)
         if err != nil {
                 log.Printf("failed to connect to target %s: %v", targetAddr, err)
                 return
         }
         defer conn.Close()

         log.Printf("direct-tcpip: %s:%d -> %s (session: %s)",
                 payload.OriginAddr, payload.OriginPort, targetAddr, session.ID)

         // Copy data between channel and connection
         var wg sync.WaitGroup
         wg.Add(2)

         go func() {
                 defer wg.Done()
                 io.Copy(channel, conn)
                 channel.CloseWrite()
         }()

         go func() {
                 defer wg.Done()
                 io.Copy(conn, channel)
                 if tcpConn, ok := conn.(*net.TCPConn); ok {
                         tcpConn.CloseWrite()
                 }

                                                                                                                                  
		         }()

        wg.Wait()
}

