package ssh_server

import (
    "fmt"
    "io"
    "log"
    "net"
    "os/exec"
    "strconv"
    "strings"
    "sync"
    //"time"
    "golang.org/x/crypto/ssh"
)

type tcpipForwardPayload struct {
        BindAddress string
        BindPort    uint32
}

type tcpipForwardSuccessPayload struct {
        BindPort uint32
}

type cancelTCPIPForwardPayload struct {
        BindAddress string
        BindPort    uint32
}

type directTCPIPPayload struct {
        Host       string
        Port       uint32
        OriginAddr string
        OriginPort uint32
}

type forwardedTCPIPPayload struct {
        ConnectedHost  string
        ConnectedPort  uint32
        OriginatorHost string
        OriginatorPort uint32
}

 type forwardKey struct {
         BindAddress string
         BindPort    uint32
 }

func configureUFWPort(port uint32) error {
        portStr := strconv.Itoa(int(port))
        cmd := exec.Command("sudo", "ufw", "allow", portStr)
        output, err := cmd.CombinedOutput()
        if err != nil {
                return fmt.Errorf("UFW allow port %s failed: %v, output: %s", portStr, err, string(output))
        }
        log.Printf("UFW allowed port %s: %s", portStr, string(output))
        return nil
}

func handleGlobalRequests(serverConn *ssh.ServerConn, reqs <-chan *ssh.Request, forwards map[forwardKey]*net.TCPListener, session *sessionInfo) {
        for req := range reqs {
                switch req.Type {
                case "tcpip-forward":
                        var p tcpipForwardPayload
                        if err := ssh.Unmarshal(req.Payload, &p); err != nil {
                                log.Printf("tcpip-forward: bad payload: %v", err)
                                req.Reply(false, nil)
                                continue
                        }

                        requestedPort := p.BindPort
                        actualPort := requestedPort
                        var listener net.Listener
                        var err error

                        // If user requested port 0, assign from range 1000-65535
                        if requestedPort == 0 {
                                // Try ports from 1000 to 65535
                                for port := uint32(1000); port <= 65535; port++ {
                                        addr := fmt.Sprintf("0.0.0.0:%d", port)
                                        listener, err = net.Listen("tcp", addr)
                                        if err == nil {
                                                actualPort = port
                                                log.Printf("assigned port %d for session %s (requested random)", actualPort, session.ID)
                                                break
                                        }
                                }

                                // If no port found in range, fallback to OS random
                                if listener == nil {
                                        randomListener, err := net.Listen("tcp", "0.0.0.0:0")
                                        if err != nil {
                                                log.Printf("failed to bind to any port: %v", err)
                                                req.Reply(false, nil)
                                                continue
                                        }
                                        listener = randomListener
                                        actualPort = uint32(randomListener.Addr().(*net.TCPAddr).Port)
                                        log.Printf("using OS-assigned random port %d for session %s", actualPort, session.ID)
                                                                                                                                               }
                        } else {
                                // User requested specific port, try to use it
                                addr := fmt.Sprintf("0.0.0.0:%d", requestedPort)
                                listener, err = net.Listen("tcp", addr)
                                if err != nil {
                                        log.Printf("cannot bind to requested port %d: %v, trying alternative ports...", requestedPort, err)

                                        // Try alternative ports in our range
                                        for port := uint32(1000); port <= 65535; port++ {
                                                addr := fmt.Sprintf("0.0.0.0:%d", port)
                                                listener, err = net.Listen("tcp", addr)
                                                if err == nil {
                                                        actualPort = port
                                                        log.Printf("using alternative port %d (requested %d) for session %s", actualPort, requestedPort, session.ID)
                                                        break
                                                }
                                        }

                                        // If still no port, fallback to OS random
                                        if listener == nil {
                                                randomListener, err := net.Listen("tcp", "0.0.0.0:0")
                                                if err != nil {
                                                        log.Printf("failed to bind to any port: %v", err)
                                                        req.Reply(false, nil)
                                                        continue
                                                }
                                                listener = randomListener
                                                actualPort = uint32(randomListener.Addr().(*net.TCPAddr).Port)
                                                log.Printf("using OS-assigned random port %d (requested %d) for session %s", actualPort, requestedPort, session.ID)
                                        }
                                } else {
                                        log.Printf("using requested port %d for session %s", actualPort, session.ID)
                                }
                        }



			                        go configureUFWPort(actualPort)

                        key := forwardKey{
                                BindAddress: p.BindAddress,
                                BindPort:    actualPort,
                        }
                        forwards[key] = listener.(*net.TCPListener)

			httpURL, httpsURL := generateForwardURL(session.BaseURL, actualPort, requestedPort)
			session.Forwards[actualPort] = &forwardInfo{
    				RequestedPort: requestedPort,
    				ActualPort:    actualPort,
    				Target:        fmt.Sprintf("%s:%d", p.BindAddress, p.BindPort),
    				HTTPURL:       httpURL,
    				HTTPSURL:      httpsURL,
			}
			log.Printf("remote port forwarding set up: %s | %s -> %s (UFW allowed) for session %s",
    				httpURL, httpsURL, session.Forwards[actualPort].Target, session.ID)
			RegisterSession(session.ID, actualPort)	
                        go serveForwards(serverConn, listener.(*net.TCPListener), session)
                        req.Reply(true, ssh.Marshal(&tcpipForwardSuccessPayload{BindPort: actualPort}))

                case "cancel-tcpip-forward":
                        var p cancelTCPIPForwardPayload
                        if err := ssh.Unmarshal(req.Payload, &p); err != nil {
                                log.Printf("cancel-tcpip-forward: bad payload: %v", err)
                                req.Reply(false, nil)
                                continue
                        }
			
			UnregisterSession(session.ID)
                        // Note: We don't remove UFW rule on cancel (as requested)
                        key := forwardKey{
                                BindAddress: p.BindAddress,
                                BindPort:    p.BindPort,
                        }
                        if listener, ok := forwards[key]; ok {
                                listener.Close()
                                delete(forwards, key)
                        }
                        delete(session.Forwards, p.BindPort)
                        req.Reply(true, nil)

                default:
                        if req.WantReply {
                                req.Reply(false, nil)
                        }
                }
        }
}

func serveForwards(serverConn *ssh.ServerConn, listener *net.TCPListener, session *sessionInfo) {
        for {
                conn, err := listener.AcceptTCP()
                if err != nil {
                        return
                }
                go handleNewForward(serverConn, conn, session)
        }
}

func handleNewForward(serverConn *ssh.ServerConn, conn *net.TCPConn, session *sessionInfo) {
        localAddr := conn.LocalAddr().(*net.TCPAddr)
        remoteAddr := conn.RemoteAddr().(*net.TCPAddr)

        payload := forwardedTCPIPPayload{
                ConnectedHost:  "localhost",
                ConnectedPort:  uint32(localAddr.Port),
                OriginatorHost: remoteAddr.IP.String(),
                OriginatorPort: uint32(remoteAddr.Port),
        }

        ch, reqs, err := serverConn.OpenChannel("forwarded-tcpip", ssh.Marshal(&payload))
        if err != nil {
                log.Printf("failed to open forwarded-tcpip channel: %v", err)
                conn.Close()
                return
        }

        log.Printf("new forwarded-tcpip connection: %s -> %s (session: %s)", remoteAddr.String(), localAddr.String(), session.ID)
        serveForward(ch, reqs, conn, session)
}

func detectAndLogHTTPRequest(data []byte, session *sessionInfo) {
    if len(data) < 4 {
        return
    }

    // Convert to string for easier parsing
    dataStr := string(data)

    // Look for HTTP methods
    methods := []string{"GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS", "PATCH"}
    for _, method := range methods {
        if strings.HasPrefix(dataStr, method) {
            // Extract the path (simplified parsing)
            lines := strings.Split(dataStr, "\r\n")
            if len(lines) > 0 {
                firstLine := strings.Fields(lines[0])
                if len(firstLine) >= 2 {
                    path := firstLine[1]
                    // Log the request (we'll use 200 as placeholder status code)
                    session.logRequest(method, path, 200)
                }
            }
            break
        }
    }
}

func generateForwardURL(baseURL string, actualPort, requestedPort uint32) (httpURL, httpsURL string) {
    // Remove http:// prefix if present
    cleanBase := strings.TrimPrefix(baseURL, "http://")
    
    // Generate HTTP URL
    if actualPort == 80 {
        httpURL = fmt.Sprintf("http://%s", cleanBase)
    } else {
        httpURL = fmt.Sprintf("http://%s:%d", cleanBase, actualPort)
    }
    
    // Generate HTTPS URL  
    if actualPort == 80 {
        httpsURL = fmt.Sprintf("https://%s", cleanBase)
    } else if actualPort == 443 {
        httpsURL = fmt.Sprintf("https://%s", cleanBase)
    } else {
        httpsURL = fmt.Sprintf("https://%s:%d", cleanBase, actualPort)
    }
    
    return httpURL, httpsURL
}

func serveForward(ch ssh.Channel, reqs <-chan *ssh.Request, conn *net.TCPConn, session *sessionInfo) {
    defer ch.Close()
    defer conn.Close()

    // Track this connection
    session.mu.Lock()
    session.ActiveConns++
    session.TotalConns++
    session.mu.Unlock()

    defer func() {
        session.mu.Lock()
        session.ActiveConns--
        session.mu.Unlock()
    }()

    go func() {
        for range reqs {
        }
    }()

    var wg sync.WaitGroup
    wg.Add(2)

    // Create a wrapper to sniff HTTP traffic
    type readResult struct {
        n   int
        err error
        buf []byte
    }

    readChan := make(chan readResult, 1)

    // Reader goroutine that detects HTTP requests
    go func() {
        buf := make([]byte, 4096)
        for {
            n, err := conn.Read(buf)
            readChan <- readResult{n: n, err: err, buf: append([]byte{}, buf[:n]...)}
            if err != nil {
		                    break
            }
        }
    }()

    var received, sent uint64

    go func() {
        defer wg.Done()
        for {
            select {
            case result := <-readChan:
                if result.err != nil {
                    return
                }
                // Detect HTTP request
                if len(result.buf) > 0 {
                    detectAndLogHTTPRequest(result.buf, session)
                }
                n, err := ch.Write(result.buf)
                if err != nil {
                    return
                }
                received += uint64(n)
                session.updateTraffic(received, 0, false)
            }
        }
    }()

    go func() {
        defer wg.Done()
        n, _ := io.Copy(conn, ch)
        sent = uint64(n)
        session.updateTraffic(0, sent, true)
        conn.CloseWrite()
    }()

    wg.Wait()
}

