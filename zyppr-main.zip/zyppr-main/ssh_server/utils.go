package ssh_server

import (
   // "crypto/rand"
    "fmt"
    "strings"
    "github.com/skip2/go-qrcode"
)

func generateWelcomeMessage(session *sessionInfo) string {
	message := ""
	message += fmt.Sprintf("Session ID: %s\r\n", session.ID)

        if session.Username == "qr" {
                message += fmt.Sprintf("Your base URL: %s\r\n", session.BaseURL)
                message += fmt.Sprintf("\r\n=== Active Forwards ===\r\n")

                if len(session.Forwards) == 0 {
                        message += fmt.Sprintf("No active forwards yet.\r\n")
                        message += fmt.Sprintf("Set up forwarding with: ssh -p 2222 -R 80:localhost:8000 qr@tunl.zyppr.xyz\r\n")
                        message += fmt.Sprintf("Or use random port: ssh -p 2222 -R 0:localhost:8000 qr@tunl.zyppr.xyz\r\n")
                } else {
                        for _, forward := range session.Forwards {
                                portInfo := fmt.Sprintf("port %d", forward.ActualPort)
                                if forward.RequestedPort == 0 {
                                        portInfo = "random port"
                                } else if forward.RequestedPort != forward.ActualPort {
                                        portInfo = fmt.Sprintf("port %d (requested %d)", forward.ActualPort, forward.RequestedPort)
                                }

                                //message += fmt.Sprintf("• %s -> %s (%s)\r\n", forward.URL, forward.Target, portInfo)
                        	message += fmt.Sprintf("• %s | %s -> %s (%s)\r\n", forward.HTTPURL, forward.HTTPSURL, forward.Target, portInfo)
			}
                }
                message += fmt.Sprintf("\r\n")
        } else {
                message += fmt.Sprintf("Remote forwarding supported. Examples:\r\n")
                message += fmt.Sprintf("  ssh -p 2222 -R 80:localhost:8000 test@SERVER_IP\r\n")
                message += fmt.Sprintf("  ssh -p 2222 -R 0:localhost:8000 test@SERVER_IP\r\n")
                message += fmt.Sprintf("  ssh -p 2222 -R 80:localhost:8000 -R 443:localhost:8443 test@SERVER_IP\r\n\r\n")
        }

        return message
}


func generateQRCode(url string) string {
    var qrString strings.Builder

    // Use a smaller QR code version
    qr, err := qrcode.New(url, qrcode.Low)
    if err != nil {
        return fmt.Sprintf("Error generating QR code: %v\r\n", err)
    }

    
    bitmap := qr.Bitmap()

    qrString.Write([]byte("\033[?1049h\033[2J\033[H"))
    qrString.WriteString("\033[2;50H                 Welcome to Zyppr Tunnels       \r\n")
    qrString.WriteString("\033[3;41H This is a free version. Your session will expire in 40 minutes. Upgrade to Pro!\r\n")
    qrString.WriteString("\033[6;13H SCAN WITH YOUR PHONE                     \r\n")
	
    for y := 0; y < len(bitmap); y += 2 {
        qrString.WriteString("    ")
        for x := 0; x < len(bitmap[y]); x++ {
            top := bitmap[y][x]
            bottom := y+1 < len(bitmap) && bitmap[y+1][x]

            if top && bottom {
                qrString.WriteString("█") // Full block
            } else if top && !bottom {
                qrString.WriteString("▀") // Upper half
            } else if !top && bottom {
                qrString.WriteString("▄") // Lower half
            } else {
                qrString.WriteString(" ") // Space
            }
        }
        qrString.WriteString("\r\n")
    }
    qrString.WriteString(fmt.Sprintf("URL: %s\r\n", url))

    return qrString.String()
}

func formatBytes(bytes uint64) string {
        if bytes < 1024 {
                return fmt.Sprintf("%dB", bytes)
        } else if bytes < 1024*1024 {
                return fmt.Sprintf("%.1fK", float64(bytes)/1024)
        } else {
                return fmt.Sprintf("%.1fM", float64(bytes)/(1024*1024))
        }
}

const landingPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zyppr Tunnel - {{.SessionID}}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 40px;
            text-align: center;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        .logo {
            font-size: 2.5em;
            font-weight: bold;
            margin-bottom: 10px;
            background: linear-gradient(45deg, #fff, #e0e0e0);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .status {
            background: rgba(255, 255, 255, 0.2);
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
            font-family: 'Courier New', monospace;
        }
        .stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin: 20px 0;
        }
        .stat-item {
            background: rgba(255, 255, 255, 0.15);
            padding: 15px;
            border-radius: 10px;
        }
        .url {
            background: rgba(0, 0, 0, 0.3);
            padding: 12px;
            border-radius: 8px;
            margin: 15px 0;
            word-break: break-all;
            font-family: 'Courier New', monospace;
        }
        .btn {
            background: rgba(255, 255, 255, 0.2);
            border: 2px solid rgba(255, 255, 255, 0.3);
            color: white;
            padding: 12px 30px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
            margin: 5px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }
        .btn-primary {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.5);
            font-weight: bold;
        }
        .btn-primary:hover {
            background: rgba(255, 255, 255, 0.4);
        }
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .service-status {
            margin: 15px 0;
            padding: 10px;
            border-radius: 8px;
        }
        .service-up {
            background: rgba(76, 175, 80, 0.3);
            border: 1px solid rgba(76, 175, 80, 0.5);
        }
        .service-down {
            background: rgba(244, 67, 54, 0.3);
            border: 1px solid rgba(244, 67, 54, 0.5);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">Z⁴</div>
        <h1>Tunnel Active</h1>
        <p>Your secure tunnel is running</p>

        <div class="status">
            <div class="loading"></div>
            <span id="status-text">Checking service status...</span>
        </div>

        <div id="service-status" class="service-status service-down" style="display: none;">
            ⚠️ Service not responding yet
        </div>

        <div class="stats">
            <div class="stat-item">
                <div>Session</div>
                <strong>{{.SessionID}}</strong>
            </div>
            <div class="stat-item">
                <div>Port</div>
                <strong>{{.Port}}</strong>
            </div>
        </div>

        <div class="url">
            {{.URL}}
        </div>

        <div style="margin: 25px 0;">
            <a href="/" class="btn" id="visit-btn" style="display: none;">
                🚀 Visit Your Site
            </a>
            <button class="btn" onclick="checkService()">
                🔄 Check Status
            </button>
        </div>

        <div style="font-size: 0.9em; opacity: 0.8; margin-top: 20px;">
            <p>If your local service is running, click "Visit Your Site" to access it</p>
            <p>Powered by Zyppr Tunnels</p>
        </div>
    </div>

    <script>
        let serviceChecked = false;

        // Check service status on page load
        window.addEventListener('load', function() {
            checkService();
        });

        function checkService() {
            const statusText = document.getElementById('status-text');
            const serviceStatus = document.getElementById('service-status');
            const visitBtn = document.getElementById('visit-btn');

            statusText.innerHTML = '<div class="loading"></div> Checking service...';
            serviceStatus.style.display = 'none';
            visitBtn.style.display = 'none';

            // Try to fetch the current page (which will proxy to the actual service)
            fetch(window.location.href, {
                method: 'GET',
                headers: {
                    'X-Check-Service': 'true'  // Add header to identify this as a status check
                }
            })
            .then(response => {
                if (response.status === 200) {
                    // Service is responding!
                    statusText.innerHTML = '✅ Service is ready!';
                    serviceStatus.className = 'service-status service-up';
                    serviceStatus.innerHTML = '✅ Your local service is responding';
                    serviceStatus.style.display = 'block';

                    // Show the visit button
                    visitBtn.style.display = 'inline-block';
                    visitBtn.href = window.location.href; // Link to the actual service

                    serviceChecked = true;
                } else {
                    throw new Error('Service not ready');
                }
            })
            .catch(error => {
                statusText.innerHTML = '⏳ Waiting for service...';
                serviceStatus.className = 'service-status service-down';
                serviceStatus.innerHTML = '⚠️ Make sure your local service is running on port {{.Port}}';
                serviceStatus.style.display = 'block';

                // Auto-retry after 3 seconds if not manually checked yet
                if (!serviceChecked) {
                    setTimeout(checkService, 3000);
                }
            });
        }

        // Auto-refresh status every 10 seconds
        setInterval(checkService, 10000);
    </script>
</body>
</html>`
