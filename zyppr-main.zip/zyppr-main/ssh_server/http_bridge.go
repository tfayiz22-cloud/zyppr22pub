package ssh_server

import (
    "log"
    "strconv"
)

// These will be set by the main package
var (
    RegisterSessionFunc   func(string, string)
    UnregisterSessionFunc func(string)
)

// SetSessionCallbacks allows main package to set the callback functions
func SetSessionCallbacks(registerFunc func(string, string), unregisterFunc func(string)) {
    RegisterSessionFunc = registerFunc
    UnregisterSessionFunc = unregisterFunc
}

// RegisterSession calls the main package's register function
func RegisterSession(sessionID string, port uint32) {
    if RegisterSessionFunc != nil {
        RegisterSessionFunc(sessionID, strconv.Itoa(int(port)))
    } else {
        log.Printf("WARNING: RegisterSessionFunc not set for session %s port %d", sessionID, port)
    }
}

// UnregisterSession calls the main package's unregister function
func UnregisterSession(sessionID string) {
    if UnregisterSessionFunc != nil {
        UnregisterSessionFunc(sessionID)
    }
}
